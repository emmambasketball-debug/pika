// ============================================================
//  server.js — Cute Chat App backend (Node.js + Express + Socket.io)
//  Everything lives in memory. Simple on purpose — see README for v2 ideas.
// ============================================================

const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

// ------------------------------------------------------------
//  In-memory "database"
// ------------------------------------------------------------

// users[username] = { username, socketId (null if offline), friends: Set<username> }
const users = {};

// chatRooms[roomId] = [ {from, type: 'text'|'image', content, time} ]
const chatRooms = {};

// sessions[sessionId] = { id, game, players:[u1,u2], sockets:[id1,id2], room, state }
const sessions = {};

// pendingInvites[inviteId] = { from, to, game }
const pendingInvites = {};

function roomIdFor(userA, userB) {
  return [userA, userB].sort().join("__");
}

function otherPlayer(session, username) {
  return session.players.find((p) => p !== username);
}

function socketFor(username) {
  const u = users[username];
  return u && u.socketId ? io.sockets.sockets.get(u.socketId) : null;
}

function emitToUser(username, event, payload) {
  const s = socketFor(username);
  if (s) s.emit(event, payload);
}

function friendListPayload(username) {
  const u = users[username];
  if (!u) return [];
  return [...u.friends].map((f) => ({
    username: f,
    online: !!(users[f] && users[f].socketId),
  }));
}

// ------------------------------------------------------------
//  Game logic helpers (server is the source of truth)
// ------------------------------------------------------------

const EMOJI_DECK = ["🐱", "🐶", "🐼", "🦊", "🐸", "🦄", "🍓", "🍩"];

function newGameState(game) {
  if (game === "tictactoe") {
    return { board: Array(9).fill(null), turn: 0, winner: null, draw: false };
  }
  if (game === "rps") {
    return { choices: [null, null], result: null, round: 1, scores: [0, 0] };
  }
  if (game === "memory") {
    const pairs = [...EMOJI_DECK, ...EMOJI_DECK];
    for (let i = pairs.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pairs[i], pairs[j]] = [pairs[j], pairs[i]];
    }
    return {
      deck: pairs,
      flipped: [],
      matched: [],
      turn: 0,
      scores: [0, 0],
      winner: null,
    };
  }
  return {};
}

const TTT_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
];

function applyMove(session, playerIndex, move) {
  const s = session.state;

  if (session.game === "tictactoe") {
    if (s.winner || s.draw) return;
    if (s.turn !== playerIndex) return;
    const idx = move.cellIndex;
    if (typeof idx !== "number" || s.board[idx]) return;
    s.board[idx] = playerIndex === 0 ? "❌" : "⭕";
    for (const line of TTT_LINES) {
      const [a, b, c] = line;
      if (s.board[a] && s.board[a] === s.board[b] && s.board[b] === s.board[c]) {
        s.winner = playerIndex;
      }
    }
    if (!s.winner && s.board.every((c) => c)) s.draw = true;
    if (!s.winner && !s.draw) s.turn = 1 - s.turn;
    broadcastState(session);
    return;
  }

  if (session.game === "rps") {
    if (s.choices[playerIndex]) return; // already chose this round
    s.choices[playerIndex] = move.choice;
    if (s.choices[0] && s.choices[1]) {
      s.result = rpsWinner(s.choices[0], s.choices[1]);
      if (s.result === 0 || s.result === 1) s.scores[s.result]++;
      broadcastState(session);
      setTimeout(() => {
        s.choices = [null, null];
        s.result = null;
        s.round++;
        broadcastState(session);
      }, 2200);
      return;
    }
    broadcastState(session);
    return;
  }

  if (session.game === "memory") {
    if (s.winner) return;
    if (s.turn !== playerIndex) return;
    const idx = move.cardIndex;
    if (typeof idx !== "number") return;
    if (s.matched.includes(idx) || s.flipped.includes(idx)) return;
    if (s.flipped.length >= 2) return;

    s.flipped.push(idx);
    broadcastState(session);

    if (s.flipped.length === 2) {
      const [a, b] = s.flipped;
      const isMatch = s.deck[a] === s.deck[b];
      setTimeout(() => {
        if (isMatch) {
          s.matched.push(a, b);
          s.scores[playerIndex]++;
          s.flipped = [];
          if (s.matched.length === s.deck.length) {
            s.winner = s.scores[0] === s.scores[1] ? "tie" : (s.scores[0] > s.scores[1] ? 0 : 1);
          }
        } else {
          s.flipped = [];
          s.turn = 1 - s.turn;
        }
        broadcastState(session);
      }, 900);
    }
  }
}

function rpsWinner(a, b) {
  if (a === b) return "tie";
  const beats = { rock: "scissors", paper: "rock", scissors: "paper" };
  return beats[a] === b ? 0 : 1;
}

function broadcastState(session) {
  session.players.forEach((p, i) => {
    emitToUser(p, "game:update", {
      sessionId: session.id,
      game: session.game,
      state: session.state,
      you: i,
    });
  });
}

// ------------------------------------------------------------
//  Socket.io wiring
// ------------------------------------------------------------

io.on("connection", (socket) => {
  let currentUser = null;

  socket.on("login", ({ username }) => {
    username = (username || "").trim().slice(0, 20);
    if (!username) return;
    currentUser = username;
    if (!users[username]) {
      users[username] = { username, socketId: null, friends: new Set() };
    }
    users[username].socketId = socket.id;
    socket.emit("login:ok", {
      username,
      friends: friendListPayload(username),
    });
    // tell friends this user is online
    users[username].friends.forEach((f) => {
      emitToUser(f, "friend:status", { username, online: true });
    });
  });

  socket.on("friend:add", ({ username }) => {
    username = (username || "").trim();
    if (!currentUser || !username || username === currentUser) {
      socket.emit("friend:error", { message: "That's not a valid username." });
      return;
    }
    if (!users[username]) {
      socket.emit("friend:error", { message: `No one named "${username}" has joined yet.` });
      return;
    }
    users[currentUser].friends.add(username);
    users[username].friends.add(currentUser);
    socket.emit("friend:list", friendListPayload(currentUser));
    emitToUser(username, "friend:list", friendListPayload(username));
    emitToUser(username, "friend:status", { username: currentUser, online: true });
  });

  socket.on("chat:join", ({ friend }) => {
    if (!currentUser) return;
    const room = roomIdFor(currentUser, friend);
    socket.join(room);
    socket.emit("chat:history", {
      friend,
      messages: chatRooms[room] || [],
    });
  });

  socket.on("chat:send", ({ friend, type, content }) => {
    if (!currentUser) return;
    const room = roomIdFor(currentUser, friend);
    const msg = { from: currentUser, type, content, time: Date.now() };
    if (!chatRooms[room]) chatRooms[room] = [];
    chatRooms[room].push(msg);
    if (chatRooms[room].length > 200) chatRooms[room].shift(); // keep it light
    io.to(room).emit("chat:message", { room, msg });
    // make sure the recipient's socket is in the room even if they haven't opened the chat
    const s = socketFor(friend);
    if (s) s.join(room);
  });

  socket.on("game:invite", ({ to, game }) => {
    if (!currentUser) return;
    if (!users[to] || !users[to].socketId) {
      socket.emit("game:error", { message: `${to} isn't online right now.` });
      return;
    }
    const inviteId = `${currentUser}-${to}-${Date.now()}`;
    pendingInvites[inviteId] = { from: currentUser, to, game };
    emitToUser(to, "game:invited", { inviteId, from: currentUser, game });
  });

  socket.on("game:respond", ({ inviteId, accept }) => {
    const invite = pendingInvites[inviteId];
    if (!invite) return;
    delete pendingInvites[inviteId];
    if (!accept) {
      emitToUser(invite.from, "game:declined", { by: invite.to });
      return;
    }
    const sessionId = `s-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const session = {
      id: sessionId,
      game: invite.game,
      players: [invite.from, invite.to],
      room: roomIdFor(invite.from, invite.to),
      state: newGameState(invite.game),
    };
    sessions[sessionId] = session;
    session.players.forEach((p, i) => {
      emitToUser(p, "game:start", {
        sessionId,
        game: invite.game,
        opponent: otherPlayer(session, p),
        you: i,
        state: session.state,
      });
    });
  });

  socket.on("game:move", ({ sessionId, move }) => {
    const session = sessions[sessionId];
    if (!session || !currentUser) return;
    const playerIndex = session.players.indexOf(currentUser);
    if (playerIndex === -1) return;
    applyMove(session, playerIndex, move);
  });

  socket.on("game:leave", ({ sessionId }) => {
    const session = sessions[sessionId];
    if (!session) return;
    const leaver = currentUser;
    session.players.forEach((p) => {
      if (p !== leaver) emitToUser(p, "game:ended", { by: leaver });
    });
    delete sessions[sessionId];
  });

  socket.on("disconnect", () => {
    if (currentUser && users[currentUser]) {
      users[currentUser].socketId = null;
      users[currentUser].friends.forEach((f) => {
        emitToUser(f, "friend:status", { username: currentUser, online: false });
      });
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✨ Cute Chat App running at http://localhost:${PORT}`);
});
