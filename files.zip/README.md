# 🌸 Pika — Chat & Play (MVP)

A cute, mobile-first web app where friends can chat in real time, send photos,
and play three 2‑player mini‑games together (Tic Tac Toe, Rock Paper Scissors,
Memory Match) — with a "Playing together!" moment and the ability to snap a
photo of the game and drop it straight into the chat.

---

## 1. App overview

**Core loop:** pick a username → add a friend by their exact username → open
the chat → talk, send photos, or tap 🎮 to invite them to a game → both players
see a "Playing together!" transition → play in real time → capture the moment
and send it back to the chat as a photo.

**Tech choice (why):** Node.js + Express + Socket.io. It's the fastest way to
get *true* real-time behavior (chat + turn-based game sync) without standing
up Firebase security rules or Cloud Functions. Everything is in-memory —
no database setup required to try it out.

**Style:** pastel pink/lavender/mint palette, rounded "soft UI" cards,
Fredoka (headers) + Nunito (body) from Google Fonts, blob animations,
bounce/pop micro-animations, and emoji used as the primary iconography
instead of custom icon assets — keeps it cute *and* keeps the code simple.

---

## 2. File structure

```
cute-chat-app/
├── package.json          # dependencies (express, socket.io)
├── server.js             # backend: users, friends, chat relay, game logic
├── public/
│   ├── index.html         # all screens (login, home, chat, games, modals)
│   ├── style.css          # pastel/rounded design system + animations
│   └── app.js              # all frontend logic + socket.io client handlers
└── README.md
```

No build step. No bundler. Open `public/` files directly and you can read
top to bottom.

---

## 3. Full working code

All files are in the project folder shared with this response:
`package.json`, `server.js`, `public/index.html`, `public/style.css`,
`public/app.js`.

A few implementation notes worth knowing about:

- **Data model is in-memory** (see the top of `server.js`):
  - `users[username] = { socketId, friends: Set }`
  - `chatRooms[roomId] = [ { from, type, content, time } ]` — roomId is just
    the two usernames sorted and joined, e.g. `"alice__bob"`.
  - `sessions[sessionId] = { game, players, state }` — one active game between
    two players.
  - Everything resets when the server restarts. That's intentional for an
    MVP — swap in a real DB later (see v2 ideas).
- **The server is the source of truth for game state.** Clients never
  "win" a game locally — they send a move, the server validates whose turn
  it is, updates the board, and broadcasts the new state to both players.
  This is what keeps the two screens perfectly in sync.
- **Photos** are sent as base64 data URLs directly through the socket
  connection as a chat message of `type: "image"`. Simple, no file storage
  needed for an MVP (real uploads/CDN is a v2 item).
- **Gameplay screenshots** use the `html2canvas` library (loaded from CDN in
  `index.html`) to literally snapshot the `#screen-game` element, which is
  then sent through the same photo-sending flow as any other picture.

---

## 4. Setup instructions

**Requirements:** Node.js 18+ installed.

```bash
# 1. Go into the project folder
cd cute-chat-app

# 2. Install dependencies
npm install

# 3. Start the server
npm start

# 4. Open the app
# → http://localhost:3000
```

**To test chat + games between two "people":** open the URL in two different
browser tabs (or one normal + one incognito window, since usernames are
stored in localStorage per-browser-profile). Log in with two different
usernames, add each other as friends by exact username, and start chatting.

**To test on your phone on the same WiFi:** find your computer's local IP
(e.g. `192.168.1.23`), run the server, and visit `http://192.168.1.23:3000`
from your phone. The 📷 button uses `capture="environment"` so it opens the
phone's camera directly.

**Deploying it for real:** any Node host works (Render, Railway, Fly.io,
a small VPS). Socket.io needs a host that supports WebSockets/long-lived
connections (most do — static-only hosts like plain GitHub Pages won't work
since this needs a running server).

---

## 5. How real-time chat + games sync works

**Chat:**
1. Client emits `chat:join` with the friend's username when a chat is opened.
2. Server computes a shared room id (`sortedUsernames.join("__")`) and joins
   that socket to the Socket.io room, then replies with message history.
3. Sending a message emits `chat:send`; the server stores it and does
   `io.to(room).emit("chat:message", ...)` — both sockets in that room (i.e.
   both friends) get it instantly, whether they're actively looking at the
   chat or not.

**Friends:**
- Adding a friend is instant/mutual for MVP simplicity (no "pending request"
  step yet — see v2 ideas). The server just needs the other username to have
  logged in at least once.

**Games:**
1. Player A taps 🎮 → picks a game → client emits `game:invite`.
2. Server relays it to player B as `game:invited` (a popup with Accept/Decline).
3. On accept, the server creates a `session` with fresh game state and emits
   `game:start` to **both** players (each gets their own `you: 0 | 1` index).
4. Both clients show the "Playing together!" animation, then render the game
   board from the shared `state` object.
5. Every tap (place a mark, flip a card, throw rock/paper/scissors) emits
   `game:move`. The **server** validates the move, updates `state`, and
   broadcasts `game:update` to both players — so both boards update at the
   same time, and cheating/out-of-turn moves are rejected server-side rather
   than trusted from the client.
6. Win/draw/tie detection happens on the server for all three games so both
   clients always agree on the result.

---

## 6. Ideas to improve in v2

- **Real accounts:** passwords or magic-link auth instead of "just type a
  username"; persistent friend codes (like a shareable `#AB12CD` code) instead
  of exact-username matching.
- **Real database:** move from in-memory objects to something like
  Postgres/Firebase/Supabase so chat history and friends survive a restart,
  plus pagination for long chat histories.
- **Proper friend requests:** a pending/accept step instead of instant mutual
  add, plus a "remove friend" and block option.
- **Push notifications** for new messages/game invites when the app isn't
  open (Web Push).
- **Media storage:** upload photos to S3/Cloud Storage and store a URL
  instead of a full base64 blob in memory — much more scalable.
- **Typing indicators & read receipts** for chat.
- **More games** and a shared "game history" / win-streak stats per friend.
- **Group chats** and group mini-games (not just 1:1).
- **Reconnect handling:** if a player's socket drops mid-game, pause the
  session and let them rejoin instead of ending it immediately.
- **Sounds & haptics** for message pop-ins and game moments (kept out of
  the MVP to avoid autoplay-permission complexity).
