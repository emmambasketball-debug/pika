// ============================================================
//  app.js — Cute Chat App frontend logic
// ============================================================

const socket = io();

let me = localStorage.getItem("pika_username") || "";
let friends = [];
let currentChatFriend = null;
let currentSession = null; // { id, game, you, state }
let pendingInviteId = null;
let pendingPhotoDataUrl = null;

const EMOJIS = ["😊","😂","🥰","😎","🥳","😭","🤔","😴","👍","👏","🎉","🔥","💖","🌸","🐱","🐶","🍕","☕","🎮","✨","😜","😇","🙈","💌"];

// ------------------------------------------------------------
//  Screen helpers
// ------------------------------------------------------------
function showScreen(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}
function openModal(id) {
  document.getElementById("modal-overlay").classList.remove("hidden");
  document.querySelectorAll(".modal").forEach((m) => m.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}
function closeModal() {
  document.getElementById("modal-overlay").classList.add("hidden");
}
function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.add("hidden"), 2400);
}
function pickAvatar(name) {
  const set = ["🐱","🐶","🦊","🐼","🐰","🦄","🐸","🐻","🐨","🐹"];
  let sum = 0;
  for (const c of name) sum += c.charCodeAt(0);
  return set[sum % set.length];
}

// ------------------------------------------------------------
//  Login
// ------------------------------------------------------------
if (me) document.getElementById("login-input").value = me;

document.getElementById("login-btn").addEventListener("click", doLogin);
document.getElementById("login-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter") doLogin();
});

function doLogin() {
  const val = document.getElementById("login-input").value.trim();
  if (!val) {
    document.getElementById("login-error").textContent = "type a username first 🐣";
    return;
  }
  socket.emit("login", { username: val });
}

socket.on("login:ok", ({ username, friends: fl }) => {
  me = username;
  localStorage.setItem("pika_username", me);
  document.getElementById("my-name").textContent = me;
  document.getElementById("my-avatar").textContent = pickAvatar(me);
  friends = fl;
  renderFriends();
  showScreen("screen-home");
});

// re-login automatically if we already have a saved name (nice for refresh)
socket.on("connect", () => {
  if (me) socket.emit("login", { username: me });
});

// ------------------------------------------------------------
//  Friends
// ------------------------------------------------------------
document.getElementById("add-friend-open").addEventListener("click", () => {
  document.getElementById("add-friend-input").value = "";
  document.getElementById("add-friend-error").textContent = "";
  openModal("modal-add-friend");
});

document.getElementById("add-friend-submit").addEventListener("click", () => {
  const val = document.getElementById("add-friend-input").value.trim();
  if (!val) return;
  socket.emit("friend:add", { username: val });
});

socket.on("friend:error", ({ message }) => {
  document.getElementById("add-friend-error").textContent = message;
});

socket.on("friend:list", (fl) => {
  friends = fl;
  renderFriends();
  closeModal();
});

socket.on("friend:status", ({ username, online }) => {
  const f = friends.find((x) => x.username === username);
  if (f) {
    f.online = online;
    renderFriends();
    if (currentChatFriend === username) updateChatHeaderStatus();
  }
});

function renderFriends() {
  const list = document.getElementById("friend-list");
  list.innerHTML = "";
  friends
    .slice()
    .sort((a, b) => b.online - a.online || a.username.localeCompare(b.username))
    .forEach((f) => {
      const el = document.createElement("div");
      el.className = "friend-item";
      el.innerHTML = `
        <span class="avatar">${pickAvatar(f.username)}</span>
        <div class="friend-info">
          <div class="friend-name">${escapeHtml(f.username)}</div>
          <div class="friend-status">
            <span class="status-dot ${f.online ? "online" : "offline"}"></span>${f.online ? "online" : "offline"}
          </div>
        </div>
        <span>💬</span>
      `;
      el.addEventListener("click", () => openChat(f.username));
      list.appendChild(el);
    });
}

// ------------------------------------------------------------
//  Chat
// ------------------------------------------------------------
document.getElementById("chat-back").addEventListener("click", () => showScreen("screen-home"));

function openChat(friendUsername) {
  currentChatFriend = friendUsername;
  document.getElementById("chat-friend-name").textContent = friendUsername;
  document.getElementById("chat-avatar").textContent = pickAvatar(friendUsername);
  updateChatHeaderStatus();
  document.getElementById("chat-messages").innerHTML = "";
  socket.emit("chat:join", { friend: friendUsername });
  showScreen("screen-chat");
}

function updateChatHeaderStatus() {
  const f = friends.find((x) => x.username === currentChatFriend);
  document.getElementById("chat-friend-status").textContent = f && f.online ? "🟢 online" : "⚪ offline";
}

socket.on("chat:history", ({ friend, messages }) => {
  if (friend !== currentChatFriend) return;
  const box = document.getElementById("chat-messages");
  box.innerHTML = "";
  messages.forEach(renderMessage);
  box.scrollTop = box.scrollHeight;
});

socket.on("chat:message", ({ msg }) => {
  const relevantFriend = msg.from === me ? currentChatFriend : msg.from;
  if (relevantFriend !== currentChatFriend) return;
  renderMessage(msg);
  const box = document.getElementById("chat-messages");
  box.scrollTop = box.scrollHeight;
});

function renderMessage(msg) {
  const box = document.getElementById("chat-messages");
  const row = document.createElement("div");
  row.className = "bubble-row " + (msg.from === me ? "me" : "them");
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  if (msg.type === "image") {
    const img = document.createElement("img");
    img.src = msg.content;
    bubble.appendChild(img);
  } else {
    bubble.textContent = msg.content;
  }
  const time = document.createElement("div");
  time.className = "bubble-time";
  time.textContent = new Date(msg.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  bubble.appendChild(time);
  row.appendChild(bubble);
  box.appendChild(row);
}

document.getElementById("chat-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const input = document.getElementById("chat-text-input");
  const text = input.value.trim();
  if (!text || !currentChatFriend) return;
  socket.emit("chat:send", { friend: currentChatFriend, type: "text", content: text });
  input.value = "";
  document.getElementById("emoji-picker").classList.add("hidden");
});

// emoji picker
const emojiPicker = document.getElementById("emoji-picker");
EMOJIS.forEach((em) => {
  const span = document.createElement("span");
  span.textContent = em;
  span.addEventListener("click", () => {
    document.getElementById("chat-text-input").value += em;
  });
  emojiPicker.appendChild(span);
});
document.getElementById("chat-emoji-btn").addEventListener("click", () => {
  emojiPicker.classList.toggle("hidden");
});

// photo sending
document.getElementById("chat-photo-btn").addEventListener("click", () => {
  document.getElementById("chat-photo-input").click();
});
document.getElementById("chat-photo-input").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    pendingPhotoDataUrl = reader.result;
    document.getElementById("photo-preview-img").src = pendingPhotoDataUrl;
    openModal("modal-photo-preview");
  };
  reader.readAsDataURL(file);
  e.target.value = "";
});
document.getElementById("photo-preview-send").addEventListener("click", () => {
  if (!pendingPhotoDataUrl || !currentChatFriend) return;
  socket.emit("chat:send", { friend: currentChatFriend, type: "image", content: pendingPhotoDataUrl });
  pendingPhotoDataUrl = null;
  closeModal();
});

// ------------------------------------------------------------
//  Modal close (generic)
// ------------------------------------------------------------
document.querySelectorAll("[data-close-modal]").forEach((btn) => {
  btn.addEventListener("click", closeModal);
});

// ------------------------------------------------------------
//  Game: invite flow
// ------------------------------------------------------------
document.getElementById("chat-play-open").addEventListener("click", () => openModal("modal-play"));

document.querySelectorAll(".game-choice").forEach((btn) => {
  btn.addEventListener("click", () => {
    const game = btn.dataset.game;
    if (!currentChatFriend) return;
    socket.emit("game:invite", { to: currentChatFriend, game });
    closeModal();
    toast(`Invite sent to ${currentChatFriend}! 🎮`);
  });
});

const GAME_NAMES = { tictactoe: "Tic Tac Toe ❌⭕", rps: "Rock Paper Scissors ✊✋✌️", memory: "Memory Match 🐱🃏" };

socket.on("game:invited", ({ inviteId, from, game }) => {
  pendingInviteId = inviteId;
  document.getElementById("invite-from").textContent = from;
  document.getElementById("invite-game-name").textContent = GAME_NAMES[game] || game;
  openModal("modal-invite");
});

document.getElementById("invite-accept").addEventListener("click", () => {
  socket.emit("game:respond", { inviteId: pendingInviteId, accept: true });
  closeModal();
});
document.getElementById("invite-decline").addEventListener("click", () => {
  socket.emit("game:respond", { inviteId: pendingInviteId, accept: false });
  closeModal();
});

socket.on("game:declined", ({ by }) => {
  toast(`${by} declined the game 😢`);
});

socket.on("game:start", ({ sessionId, game, opponent, you, state }) => {
  currentSession = { id: sessionId, game, opponent, you, state };
  currentChatFriend = currentChatFriend || opponent;
  showScreen("screen-playing-together");
  document.getElementById("pt-sub").textContent = `you vs ${opponent}`;
  document.querySelectorAll("#screen-playing-together .avatar")[0].textContent = pickAvatar(me);
  document.querySelectorAll("#screen-playing-together .avatar")[1].textContent = pickAvatar(opponent);
  setTimeout(() => {
    document.getElementById("game-title").textContent = GAME_NAMES[game] || game;
    document.getElementById("game-result-banner").classList.add("hidden");
    renderGame();
    showScreen("screen-game");
  }, 1400);
});

document.getElementById("game-leave").addEventListener("click", leaveGame);

function leaveGame() {
  if (currentSession) socket.emit("game:leave", { sessionId: currentSession.id });
  currentSession = null;
  if (currentChatFriend) openChat(currentChatFriend);
  else showScreen("screen-home");
}

socket.on("game:ended", ({ by }) => {
  toast(`${by} left the game`);
  currentSession = null;
  if (currentChatFriend) openChat(currentChatFriend);
});

socket.on("game:error", ({ message }) => toast(message));

socket.on("game:update", ({ sessionId, state, you }) => {
  if (!currentSession || currentSession.id !== sessionId) return;
  currentSession.state = state;
  currentSession.you = you;
  renderGame();
});

// ------------------------------------------------------------
//  Game rendering
// ------------------------------------------------------------
function renderGame() {
  if (!currentSession) return;
  const { game, state, you } = currentSession;
  document.getElementById("game-result-banner").classList.add("hidden");
  if (game === "tictactoe") renderTicTacToe(state, you);
  if (game === "rps") renderRPS(state, you);
  if (game === "memory") renderMemory(state, you);
}

function setStatus(text) {
  document.getElementById("game-status").textContent = text;
}
function setScores(html) {
  document.getElementById("game-scores").innerHTML = html;
}
function showResultBanner(html) {
  const banner = document.getElementById("game-result-banner");
  banner.innerHTML = html;
  banner.classList.remove("hidden");
}

// ---- Tic Tac Toe ----
function renderTicTacToe(state, you) {
  setScores("");
  const area = document.getElementById("game-area");
  const board = document.createElement("div");
  board.className = "ttt-board";
  state.board.forEach((val, i) => {
    const cell = document.createElement("button");
    cell.className = "ttt-cell";
    cell.textContent = val || "";
    cell.disabled = !!val || state.winner !== null || state.draw;
    cell.addEventListener("click", () => {
      socket.emit("game:move", { sessionId: currentSession.id, move: { cellIndex: i } });
    });
    board.appendChild(cell);
  });
  area.innerHTML = "";
  area.appendChild(board);

  if (state.winner !== null) {
    const won = state.winner === you;
    setStatus(won ? "you won! 🎉" : "you lost 😢");
    showResultBanner(`
      <div style="font-size:34px">${won ? "🏆" : "🥲"}</div>
      <strong>${won ? "You won!" : "Better luck next time!"}</strong>
      <div><button class="btn btn-ghost" id="rg-rematch">Ask for a rematch</button></div>
    `);
    bindRematch();
  } else if (state.draw) {
    setStatus("it's a draw 🤝");
    showResultBanner(`<div style="font-size:34px">🤝</div><strong>Draw!</strong>`);
  } else {
    setStatus(state.turn === you ? "your turn! ✨" : "waiting for them...");
  }
}

// ---- Rock Paper Scissors ----
const RPS_EMOJI = { rock: "✊", paper: "✋", scissors: "✌️" };
function renderRPS(state, you) {
  setScores(`<span>you: ${state.scores[you]}</span><span>them: ${state.scores[1 - you]}</span>`);
  const area = document.getElementById("game-area");
  area.innerHTML = "";
  const wrap = document.createElement("div");
  wrap.className = "rps-wrap";

  if (state.result !== null) {
    const battle = document.createElement("div");
    battle.className = "rps-battle";
    battle.innerHTML = `<span>${RPS_EMOJI[state.choices[you]]}</span><span class="vs">vs</span><span>${RPS_EMOJI[state.choices[1 - you]]}</span>`;
    wrap.appendChild(battle);
    let text;
    if (state.result === "tie") text = "It's a tie! 🤝";
    else if (state.result === you) text = "You win this round! 🎉";
    else text = "They win this round 😢";
    setStatus(text);
  } else if (state.choices[you]) {
    wrap.innerHTML = `<p style="color:var(--text-light);margin-top:30px">waiting for them to choose...</p>`;
    setStatus("locked in ✅");
  } else {
    const choices = document.createElement("div");
    choices.className = "rps-choices";
    ["rock", "paper", "scissors"].forEach((c) => {
      const b = document.createElement("button");
      b.className = "rps-choice";
      b.textContent = RPS_EMOJI[c];
      b.addEventListener("click", () => {
        socket.emit("game:move", { sessionId: currentSession.id, move: { choice: c } });
      });
      choices.appendChild(b);
    });
    wrap.appendChild(choices);
    setStatus(`round ${state.round} — pick one!`);
  }
  area.appendChild(wrap);
}

// ---- Memory Match ----
function renderMemory(state, you) {
  setScores(`<span>you: ${state.scores[you]}</span><span>them: ${state.scores[1 - you]}</span>`);
  const area = document.getElementById("game-area");
  area.innerHTML = "";
  const board = document.createElement("div");
  board.className = "memory-board";
  state.deck.forEach((val, i) => {
    const card = document.createElement("button");
    const isMatched = state.matched.includes(i);
    const isFlipped = state.flipped.includes(i);
    card.className = "memory-card" + (isFlipped ? " flipped" : "") + (isMatched ? " matched" : "");
    card.textContent = isFlipped || isMatched ? val : "❓";
    card.disabled = isMatched || isFlipped || state.turn !== you || state.winner !== null || state.flipped.length >= 2;
    card.addEventListener("click", () => {
      socket.emit("game:move", { sessionId: currentSession.id, move: { cardIndex: i } });
    });
    board.appendChild(card);
  });
  area.appendChild(board);

  if (state.winner !== null) {
    const won = state.winner === you;
    const tie = state.winner === "tie";
    setStatus(tie ? "it's a tie! 🤝" : won ? "you won! 🎉" : "you lost 😢");
    showResultBanner(`
      <div style="font-size:34px">${tie ? "🤝" : won ? "🏆" : "🥲"}</div>
      <strong>${tie ? "It's a tie!" : won ? "You won!" : "Good game!"}</strong>
    `);
  } else {
    setStatus(state.turn === you ? "your turn — flip a card! ✨" : "waiting for them...");
  }
}

function bindRematch() {
  const btn = document.getElementById("rg-rematch");
  if (!btn) return;
  btn.addEventListener("click", () => {
    if (!currentSession) return;
    socket.emit("game:invite", { to: currentSession.opponent, game: currentSession.game });
    toast("Rematch invite sent! 🔁");
  });
}

// ------------------------------------------------------------
//  Capture gameplay moment -> send as photo to chat
// ------------------------------------------------------------
document.getElementById("game-capture").addEventListener("click", async () => {
  const target = document.getElementById("screen-game");
  toast("Capturing moment... 📸");
  try {
    const canvas = await html2canvas(target, { backgroundColor: "#fff6fb", useCORS: true });
    pendingPhotoDataUrl = canvas.toDataURL("image/png");
    document.getElementById("photo-preview-img").src = pendingPhotoDataUrl;
    if (!currentChatFriend && currentSession) currentChatFriend = currentSession.opponent;
    openModal("modal-photo-preview");
  } catch (err) {
    toast("Couldn't capture that, sorry!");
  }
});

// ------------------------------------------------------------
//  Utils
// ------------------------------------------------------------
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
